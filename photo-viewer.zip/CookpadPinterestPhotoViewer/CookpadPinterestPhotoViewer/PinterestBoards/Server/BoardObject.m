//
// Created by SERDAR YILLAR on 16/04/2017.
// Copyright (c) 2017 Cookpad Inc. All rights reserved.
//

#import "BoardObject.h"
#import "BoardImageObject.h"

@implementation BoardObject {

  }
@end
