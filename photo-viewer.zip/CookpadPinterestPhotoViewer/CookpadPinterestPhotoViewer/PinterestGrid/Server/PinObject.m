//
// Created by SERDAR YILLAR on 16/04/2017.
// Copyright (c) 2017 Cookpad Inc. All rights reserved.
//

#import "PinObject.h"
#import "BoardImageObject.h"

@implementation PinObject {

  }
@end
